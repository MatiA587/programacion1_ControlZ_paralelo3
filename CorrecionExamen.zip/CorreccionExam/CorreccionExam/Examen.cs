﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CorreccionExam
{
    public class Examen
    {
        public List<Pregunta> ListaPreguntas { get; set; }

        public Examen()
        {
            ListaPreguntas = new List<Pregunta>();
        }

        public void AgregarPregunta(Pregunta pregunta)
        {
            ListaPreguntas.Add(pregunta);
        }
    }
}