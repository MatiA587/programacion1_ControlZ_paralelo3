﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorreccionExam
{
    public class Correccion
    {
        public int RespuestasCorrectas { get; set; }

        public int RespuestasIncorrectas { get; set; }

        public double NotaFinal { get; set; }

        public List<string> DetallesErrores { get; set; }

        public Correccion()
        {
            DetallesErrores = new List<string>();
        }
    }
}
