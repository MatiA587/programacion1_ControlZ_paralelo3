﻿namespace CorreccionExam
{
    partial class FormMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCantidadPreguntas = new System.Windows.Forms.TextBox();
            this.txtRespuestasAlumno = new System.Windows.Forms.TextBox();
            this.txtNombreAlumno = new System.Windows.Forms.TextBox();
            this.txtRespuestasExamen = new System.Windows.Forms.TextBox();
            this.btnRegistrarExamen = new System.Windows.Forms.Button();
            this.btnCalificar = new System.Windows.Forms.Button();
            this.btnMostrarRespuestas = new System.Windows.Forms.Button();
            this.lblResultadoEstudiante = new System.Windows.Forms.Label();
            this.lblCorrectas = new System.Windows.Forms.Label();
            this.lblIncorrectas = new System.Windows.Forms.Label();
            this.lblNota = new System.Windows.Forms.Label();
            this.lstErrores = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCantidadPreguntas
            // 
            this.txtCantidadPreguntas.Location = new System.Drawing.Point(117, 74);
            this.txtCantidadPreguntas.Name = "txtCantidadPreguntas";
            this.txtCantidadPreguntas.Size = new System.Drawing.Size(189, 22);
            this.txtCantidadPreguntas.TabIndex = 0;
            this.txtCantidadPreguntas.TextChanged += new System.EventHandler(this.txtCantidadPreguntas_TextChanged);
            // 
            // txtRespuestasAlumno
            // 
            this.txtRespuestasAlumno.Location = new System.Drawing.Point(75, 383);
            this.txtRespuestasAlumno.Name = "txtRespuestasAlumno";
            this.txtRespuestasAlumno.Size = new System.Drawing.Size(189, 22);
            this.txtRespuestasAlumno.TabIndex = 1;
            this.txtRespuestasAlumno.TextChanged += new System.EventHandler(this.txtRespuestasAlumno_TextChanged);
            // 
            // txtNombreAlumno
            // 
            this.txtNombreAlumno.Location = new System.Drawing.Point(75, 339);
            this.txtNombreAlumno.Name = "txtNombreAlumno";
            this.txtNombreAlumno.Size = new System.Drawing.Size(189, 22);
            this.txtNombreAlumno.TabIndex = 2;
            // 
            // txtRespuestasExamen
            // 
            this.txtRespuestasExamen.Location = new System.Drawing.Point(117, 118);
            this.txtRespuestasExamen.Name = "txtRespuestasExamen";
            this.txtRespuestasExamen.Size = new System.Drawing.Size(189, 22);
            this.txtRespuestasExamen.TabIndex = 3;
            // 
            // btnRegistrarExamen
            // 
            this.btnRegistrarExamen.Location = new System.Drawing.Point(167, 150);
            this.btnRegistrarExamen.Name = "btnRegistrarExamen";
            this.btnRegistrarExamen.Size = new System.Drawing.Size(93, 51);
            this.btnRegistrarExamen.TabIndex = 4;
            this.btnRegistrarExamen.Text = "Registrar Examen";
            this.btnRegistrarExamen.UseVisualStyleBackColor = true;
            this.btnRegistrarExamen.Click += new System.EventHandler(this.btnRegistrarExamen_Click);
            // 
            // btnCalificar
            // 
            this.btnCalificar.Location = new System.Drawing.Point(334, 339);
            this.btnCalificar.Name = "btnCalificar";
            this.btnCalificar.Size = new System.Drawing.Size(93, 51);
            this.btnCalificar.TabIndex = 5;
            this.btnCalificar.Text = "Calificar";
            this.btnCalificar.UseVisualStyleBackColor = true;
            this.btnCalificar.Click += new System.EventHandler(this.btnCalificar_Click);
            // 
            // btnMostrarRespuestas
            // 
            this.btnMostrarRespuestas.Location = new System.Drawing.Point(576, 288);
            this.btnMostrarRespuestas.Name = "btnMostrarRespuestas";
            this.btnMostrarRespuestas.Size = new System.Drawing.Size(93, 52);
            this.btnMostrarRespuestas.TabIndex = 6;
            this.btnMostrarRespuestas.Text = "Mostrar Respuestas";
            this.btnMostrarRespuestas.UseVisualStyleBackColor = true;
            this.btnMostrarRespuestas.Click += new System.EventHandler(this.btnMostrarRespuestas_Click);
            // 
            // lblResultadoEstudiante
            // 
            this.lblResultadoEstudiante.AutoSize = true;
            this.lblResultadoEstudiante.Location = new System.Drawing.Point(549, 20);
            this.lblResultadoEstudiante.Name = "lblResultadoEstudiante";
            this.lblResultadoEstudiante.Size = new System.Drawing.Size(72, 16);
            this.lblResultadoEstudiante.TabIndex = 7;
            this.lblResultadoEstudiante.Text = "Resultado:";
            this.lblResultadoEstudiante.Click += new System.EventHandler(this.lblResultadoEstudiante_Click);
            // 
            // lblCorrectas
            // 
            this.lblCorrectas.AutoSize = true;
            this.lblCorrectas.Location = new System.Drawing.Point(549, 36);
            this.lblCorrectas.Name = "lblCorrectas";
            this.lblCorrectas.Size = new System.Drawing.Size(68, 16);
            this.lblCorrectas.TabIndex = 8;
            this.lblCorrectas.Text = "Correctas:";
            // 
            // lblIncorrectas
            // 
            this.lblIncorrectas.AutoSize = true;
            this.lblIncorrectas.Location = new System.Drawing.Point(549, 52);
            this.lblIncorrectas.Name = "lblIncorrectas";
            this.lblIncorrectas.Size = new System.Drawing.Size(76, 16);
            this.lblIncorrectas.TabIndex = 9;
            this.lblIncorrectas.Text = "Incorrectas:";
            // 
            // lblNota
            // 
            this.lblNota.AutoSize = true;
            this.lblNota.Location = new System.Drawing.Point(549, 68);
            this.lblNota.Name = "lblNota";
            this.lblNota.Size = new System.Drawing.Size(39, 16);
            this.lblNota.TabIndex = 10;
            this.lblNota.Text = "Nota:";
            // 
            // lstErrores
            // 
            this.lstErrores.FormattingEnabled = true;
            this.lstErrores.ItemHeight = 16;
            this.lstErrores.Location = new System.Drawing.Point(484, 150);
            this.lstErrores.Name = "lstErrores";
            this.lstErrores.Size = new System.Drawing.Size(281, 132);
            this.lstErrores.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 16);
            this.label1.TabIndex = 12;
            this.label1.Text = "Ingrese cantidad de preguntas:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "Ingrese respuestas correctas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "Ingrese nombre del estudiante";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(72, 364);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(209, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Ingrese respuestas del estudiante";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(484, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "Errores del estudiante:";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstErrores);
            this.Controls.Add(this.lblNota);
            this.Controls.Add(this.lblIncorrectas);
            this.Controls.Add(this.lblCorrectas);
            this.Controls.Add(this.lblResultadoEstudiante);
            this.Controls.Add(this.btnMostrarRespuestas);
            this.Controls.Add(this.btnCalificar);
            this.Controls.Add(this.btnRegistrarExamen);
            this.Controls.Add(this.txtRespuestasExamen);
            this.Controls.Add(this.txtNombreAlumno);
            this.Controls.Add(this.txtRespuestasAlumno);
            this.Controls.Add(this.txtCantidadPreguntas);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCantidadPreguntas;
        private System.Windows.Forms.TextBox txtRespuestasAlumno;
        private System.Windows.Forms.TextBox txtNombreAlumno;
        private System.Windows.Forms.TextBox txtRespuestasExamen;
        private System.Windows.Forms.Button btnRegistrarExamen;
        private System.Windows.Forms.Button btnCalificar;
        private System.Windows.Forms.Button btnMostrarRespuestas;
        private System.Windows.Forms.Label lblResultadoEstudiante;
        private System.Windows.Forms.Label lblCorrectas;
        private System.Windows.Forms.Label lblIncorrectas;
        private System.Windows.Forms.Label lblNota;
        private System.Windows.Forms.ListBox lstErrores;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

