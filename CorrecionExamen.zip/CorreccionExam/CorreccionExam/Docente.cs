﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorreccionExam
{
    public class Docente
    {
        public Examen ExamenActivo { get; private set; }

        public void RegistrarExamen(Examen examen)
        {
            ExamenActivo = examen;
        }

        public Correccion CalificarEstudiante(Estudiante estudiante)
        {
            Correccion resultado = new Correccion();

            if (ExamenActivo == null)
            {
                throw new Exception("No existe un examen registrado.");
            }

            foreach (Pregunta pregunta in ExamenActivo.ListaPreguntas)
            {
                string respuestaCorrecta = pregunta.RespuestaCorrecta;

                string respuestaAlumno = "";

                if (estudiante.RespuestasAlumno.ContainsKey(pregunta.Numero))
                {
                    respuestaAlumno =
                        estudiante.RespuestasAlumno[pregunta.Numero];
                }

                if (respuestaAlumno.Equals(
                        respuestaCorrecta,
                        StringComparison.OrdinalIgnoreCase))
                {
                    resultado.RespuestasCorrectas++;
                }
                else
                {
                    resultado.RespuestasIncorrectas++;

                    resultado.DetallesErrores.Add(
                        $"Pregunta {pregunta.Numero}: " +
                        $"Correcta = {respuestaCorrecta}, " +
                        $"Alumno = {respuestaAlumno}");
                }
            }

            int totalPreguntas = ExamenActivo.ListaPreguntas.Count;

            if (totalPreguntas > 0)
            {
                resultado.NotaFinal =
                    ((double)resultado.RespuestasCorrectas /
                     totalPreguntas) * 100;
            }

            return resultado;
        }
    }
}