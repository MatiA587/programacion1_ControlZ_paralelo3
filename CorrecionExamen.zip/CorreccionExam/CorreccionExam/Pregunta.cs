﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorreccionExam
{
    public class Pregunta
    {
        public int Numero { get; set; }

        public string RespuestaCorrecta { get; set; }

        public Pregunta(int numero, string respuestaCorrecta)
        {
            Numero = numero;
            RespuestaCorrecta = respuestaCorrecta;
        }
    }
}