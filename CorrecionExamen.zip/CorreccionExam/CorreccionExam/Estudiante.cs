﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorreccionExam
{
    public class Estudiante
    {
        public string Nombre { get; set; }

        public Dictionary<int, string> RespuestasAlumno { get; set; }

        public Estudiante(string nombre)
        {
            Nombre = nombre;

            RespuestasAlumno = new Dictionary<int, string>();
        }
    }
}